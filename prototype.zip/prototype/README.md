# Vibe Check

> **Frozen.** This Python prototype stays as it is; development continues in
> the Rust core and Godot app at the [repository root](../README.md). It works
> on a collection until that collection moves to database schema v5, which
> only the Rust version reads.

Learns how *you* label music, from the audio, and applies it to the rest of
your collection.

Not a genre classifier. There is no taxonomy, no Discogs or Beatport
vocabulary — it learns which sounds you give which colour, and nothing about
what a colour is supposed to mean. It works in the eight colour tags and five
stars Rekordbox already has, so it fits your existing workflow rather than
asking you to invent one.

Local, MIT licensed. Developed on macOS; the code is portable — CUDA, Metal or
CPU, and every other dependency is cross-platform.

---

## Install

Requires [uv](https://docs.astral.sh/uv/) and ffmpeg. Uses CUDA or Apple Metal
if present, CPU otherwise — on CPU expect roughly 3–5× longer to analyse a
batch, which is slow but workable.

```sh
brew install uv ffmpeg
git clone https://github.com/F483/vibecheck && cd vibecheck
uv sync
```

The first run downloads the audio model (~2 GB). **After that it needs no
network at all** — once the model is cached it runs fully offline, and writes
nothing outside `<your collection>/.vibecheck/` and the Rekordbox XML you point
it at.

## Usage

```sh
# point it at your collection (default: ~/Music/Collection)
uv run vibecheck scan

# label some tracks by hand first -- it needs about 200 to be useful
uv run vibecheck status

# then, each round -- one command, repeated:
uv run vibecheck label 100   # reads your corrections, learns from them, picks
                             # 100 more unlabelled tracks, and writes their
                             # colours, star ratings, key, energy and cue
                             # points into the rekordbox xml
#   ... refresh the rekordbox xml node in rekordbox's sidebar, import the new
#       vibecheck-<date>-<time> playlist, correct what is wrong while you
#       listen, export your collection again, and run the same command ...
```

It writes into **rekordbox's own colour tag and star rating**, not a text
field, by rewriting the XML rekordbox is pointed at (Preferences → Advanced →
Database → rekordbox xml). Your previous export is kept as
`rekordbox.xml.bak`. **Your music files are never touched**, and nothing changes
in rekordbox until you import the playlist.

Each batch also gets a **key** and an **energy level** (1–10), worked out from
the audio by fixed methods rather than learned: the key goes into rekordbox's
own key field in alphanumeric notation (`8A` is A minor), and
`<key> - Energy <n>` goes at the start of the comment, keeping anything else
there such as `/* tags */`. Both can be switched off in config. How they work
and how accurate they are: [docs/key-energy.md](docs/key-energy.md).

Each batch also gets **cue points**, on tracks that have no cues or only
generated ones (named "Cue 1", "Cue 2", ...) — a track with any cue you set
yourself is never touched. Where a track changes is learned from your own cues;
where the cues go around each change is plain settings: one cue at each change
by default, or e.g. a pair 16 and 8 bars ahead with loops on A and G. How it
works and how often it matches hand-set cues: [docs/cues.md](docs/cues.md).

Other things you may want:

```sh
uv run vibecheck sync                     # only read corrections back, no new batch
uv run vibecheck label 50 --dry-run       # see what it would say, change nothing
uv run vibecheck discard out/vibecheck-….m3u8   # throw a batch away, free its tracks
uv run vibecheck label 300 --include-unconfirmed   # reuse tracks from a batch
                                                   # you have not corrected yet

uv run vibecheck analyse --all --dry-run  # key and energy for the whole
                                          # collection: what would change
uv run vibecheck analyse --all            # ... and write it, with a playlist
                                          # of only the tracks that changed
uv run vibecheck cues                     # cue points for every track it has
                                          # labelled that has none of yours
uv run vibecheck cues --train             # learn cue placement from your cues now
```

A batch in progress is excluded from the next one, so batches never overlap and
a new batch cannot overwrite corrections you have not synced. `discard` forgets
a batch's unconfirmed labels; `sync` first if you have corrected some of it.

That loop is the whole product: one command, repeated. Each round it refits on
everything you have corrected so far, so each round you correct less. There is
no separate training step and no stored model for colours -- the classifier is
rebuilt from your labels at the start of every run, in about a second, on top of
cached audio embeddings that never need recomputing. Cue points are the
exception: a small network that ships trained, and is trained again on your own
cues (a few minutes) whenever 50 more of them have accumulated.

**What it writes:** the rekordbox XML it is pointed at and `<your
collection>/.vibecheck/`. Nothing else. Playlists land in `out/`. Track identity is a hash of the audio only, so writing a label
never changes what a track *is* and never invalidates its cached analysis.

**Configuration** lives in `<your collection>/.vibecheck/config.toml`, which
only needs what differs from [the default](src/vibecheck/default_config.toml).
It holds two dials:
`misleading_cost`, how bad it is to be given a wrong colour, and
`rating_misleading_cost`, the same for stars; and whether key and energy are
written (`write_tonality`, `write_comment`); and how cue points are placed
(`[cues]`: `lead`, `loops`, `memory`). The palette is not configurable —
eight colours and six star ratings is Rekordbox's UI, not a preference.

## Status

**Prototype built and in use.** The research question — can a model learn one
person's labels from audio well enough to save real work — is answered, and the
loop above is running on the reference collection.

## What it achieves

Measured on 861 tracks never used for any modelling decision, from a reference
collection of 14,194 mp3s with 8,619 hand-applied labels.

Measured as the binary decisions you still have to make, where labelling a
track by hand from eight colours costs 3.00:

```
setting              decisions left   work saved   what it says
misleading_cost 1         1.35            55%      a colour on 96%, 53% right
misleading_cost 2         1.81            40%      a colour on 41% at 67%,
                                                   a hue on 17% at 88%,
                                                   a tone on 28% at 94%
```

The star rating is decided separately, and with `rating_misleading_cost = 4`
it rates about 10% of tracks at ~81% accuracy rather than 93% at 55%.

Accuracy by granularity, against always guessing the commonest answer:

```
                      model    baseline
colour  (8 values)    56.0%      26.1%
hue     (4 values)    66.1%      32.8%
tone    (2 values)    80.1%      66.7%
```

## The result that matters most

**The model reproduces the labelling more consistently than the person does.**

300 tracks were cleared and relabelled blind, then compared against their
previous labels:

```
              you vs your past self     model
colour               45.3%              56.0%
hue                  65.7%              66.1%
tone                 70.3%              80.7%
```

So 56% is not a ceiling the model is stuck beneath — it is *above* the noise
floor of the target. Six independent approaches all converged at 56–58%
because there is no further signal to extract, not because the right technique
was missing.

That also changes what the tool is for. It is not only a labour saver: it
applies one stable judgement across 14,000 tracks and several years, which is
something no one can do by hand. See [docs/ceiling.md](docs/ceiling.md).

## How it works

```
mp3 → 24 × 10 s excerpts → CLAP embedding ─┬─▶ hue     (4 values)  ─┐
                                           ├─▶ tone    (2 values)  ─┴─▶ colour
                                           └─▶ stars   (6 values)  ────▶ rating
```

**The label is a set of independent axes, not a hierarchy.** Hue and tone form
a 4×2 grid whose cells are the eight colours, so a confident hue plus a
confident tone *is* a colour; one without the other narrows the choice without
making it. The rating is a third axis entirely — it can be sure a track is four
stars while only knowing it is Warm.

- Pretrained audio models are used **only as feature extractors**. They never
  see a label. Everything about your taste lives in a small classifier trained
  on your own tags — the structure is fixed, the meaning is entirely yours.
- There are **no confidence thresholds to set**. Each axis knows how much of
  your decision it removes — knowing the hue narrows eight colours to two,
  which is two binary choices — and speaks when `(1 − p) × (cost +
  misleading_cost) < cost`, i.e. when being right is likely enough to be worth
  the risk. The threshold is derived, not configured: 33% for hue, 50% for
  tone, 63% for the rating.
- **Two dials**: `misleading_cost` for the colour axes, and
  `rating_misleading_cost` for the stars, because a wrong star rating pollutes
  the view you use to find your best tracks where a wrong colour is just a
  wrong colour.

## Current best setup

```
model        laion/larger_clap_music_and_speech, frozen
audio        48 kHz, 24 windows × 10 s, mean and standard deviation pooled
classifier   standardise → logistic regression, C = 0.001 (chosen by CV)
decision     expected-cost policy over colour / hue / tone / abstain
storage      .vibecheck/ in the collection root: labels.db, cache.db
labels in    rekordbox XML export (colour tag + star rating)
key, energy  fixed methods, no learning: docs/key-energy.md
cue points   learned transition points + placement settings: docs/cues.md
```

Full detail, including every parameter that matters and why:
[docs/setup.md](docs/setup.md).

## What was ruled out

Recorded so it is not re-attempted. Each was measured, not assumed.

| approach | result |
|---|---|
| 5 encoders: MFCC, MERT, Whisper, CLAP, MuQ | converge within ~2 points |
| ~12 classifiers: kNN, SVC, MLP, one-vs-rest, PCA, per-label thresholds | within 2 points |
| 20× more training data | learning curves flat |
| +1,857 labels imported from rekordbox | +0.3 |
| fine-tuning the encoder | +0.6, inside noise |
| probability calibration | no effect on decisions |
| weighting by DJ play count | no effect once rating is controlled for |
| hearing 4 minutes per track instead of 90 s | +0.2 |

The two changes that *did* matter were both about how the model is used rather
than what it is: tuning regularisation (+11) and replacing confidence
thresholds with the cost policy (17 → 55 exact colours per 100).

## Open, deliberately

- **CLAP has never been exported to ONNX.** It decides whether a packaged app
  is ~500 MB or ~2 GB. Half a day of work, parked until packaging actually
  starts — see [docs/design.md](docs/design.md) §7.
- **Cloud encoders are untested on the current labels.** Worth ~$10 to settle,
  once there are around 1,000 fresh labels — before that it would mostly
  measure noise. See [docs/plan-b-cloud.md](docs/plan-b-cloud.md).
- **The encoder comparison was run against the retired labels.** Re-running it
  on fresh ones is free and may not give the same answer.

## Documentation

- [docs/key-energy.md](docs/key-energy.md) — key and energy: method, accuracy, credits
- [docs/cues.md](docs/cues.md) — cue points: method, accuracy, settings
- [docs/stats-1000.md](docs/stats-1000.md) — what 1,000 fresh labels and a month of DJing show
- [docs/setup.md](docs/setup.md) — the working configuration, reproducibly
- [docs/accuracy.md](docs/accuracy.md) — what accuracy to expect, and what limits it
- [docs/ceiling.md](docs/ceiling.md) — label consistency, and why the model beats it
- [docs/landscape.md](docs/landscape.md) — who else does this, and how this differs
- [docs/design.md](docs/design.md) — design decisions and their reasoning
- [docs/phase0-report.md](docs/phase0-report.md) — the backend comparison in full
- [docs/plan-b-cloud.md](docs/plan-b-cloud.md) — contingency, and when *not* to use it
- [docs/frontend-options.md](docs/frontend-options.md) — UI options, not started

## License

MIT — see [LICENSE](LICENSE).
