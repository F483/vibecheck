# Design notes

The reasoning behind the decisions, kept for the record.
Status: exploration. Nothing decided except what is marked **decided**.
Measurements come from the reference collection described in §3.

## 1. Idea

A local tool that learns a user's labelling of music and pre-labels new
tracks with it.

**This is not genre classification.** The app learns whatever flat set of label
strings its user provides, and assigns no meaning to them. **decided**

Example vocabulary, used as the reference throughout this document: 24 labels
— 8 colours for feel x 3 levels for how much the user likes the track, written
as strings like `Red_High`. The app never knows any of that structure; it sees
24 opaque symbols. Another user's vocabulary will look nothing like this, and
the app must not care.

Clearing out old tags is the user's own job, done before ingest and outside the
app's scope. No public vocabulary (Discogs, Beatport, ID3 genre lists) enters
anywhere. The entire point is learning one person's taste, so that a growing
collection stays under control without tedious manual management.

Consequences that follow directly from this and drive the rest of the design:

- **No free training data.** Every one of ~13.8k tracks starts unlabelled.
  Labels only exist because the user produced them, so user attention is the
  scarcest resource in the system, and the review loop (§6) *is* the product.
- **Closed vocabulary.** No new labels will ever appear, unlike an open genre
  taxonomy. Discovery of unseen classes stops being a requirement.
- Pretrained audio models are used **only as feature extractors** (audio ->
  numeric fingerprint). Every decision is learned from the user's labels.

## 2. Goals / non-goals

**Goals**
- Learn one person's taste and labelling, not a public consensus. **decided**
- Flat user-defined label set, opaque to the app; no color, rating, axis or
  genre vocabulary is hard-coded, and label strings are never parsed.
  **superseded 2026-09-15 — see §7, "The palette is fixed"**
- Handle DJ-scale collections (200 GB+ and growing). **decided**
- The label is written into the mp3's ID3 genre field, so other software
  (Rekordbox, Traktor, players, file managers) sees it. **decided**
- Runs locally on the user's own machine. **decided**
- **Cross-platform is kept open.** *(revised 2026-09-13 -- supersedes the
  earlier "mac-only" decision.)* macOS on Apple Silicon is the development
  target, but nothing in the implementation depends on it: decoding is ffmpeg,
  tags are mutagen, storage is SQLite, and the accelerator is chosen at runtime
  (CUDA, Metal, or CPU). Mac-only was adopted to simplify shipping and was
  never actually exploited, so the constraint was dropped rather than paid for.
- Corrections improve future guesses.

**Non-goals (for now)**
- Not a tag editor / library manager. It touches one field.
- Not a recommender or player — the app never plays audio; listening happens in
  the user's own music software. **decided**
- Playlists are work lists, not a feature: no smart/auto playlist generation,
  and no label information is stored in them.
- One label per track; no multi-label. **decided**
- Audio only — no metadata signals (artist/album/year/filename). **decided**
  Artist is probably the strongest predictor of any user's labels; it is
  excluded deliberately so the model learns sound, not lookup. Revisit later.
- Track-level labels only; no per-cue-region analysis. **decided**
- No near-duplicate detection: remixes, edits and re-rips are separate tracks.
  **decided** Caveat: duplicates split across train/test inflate cross-validation
  scores, so use artist-grouped splits for any number worth trusting.

## 3. Requirements

### Functional
- **Scan**: walk one or more root folders, find mp3s, read the ID3 genre field.
- **Index**: persist state in the collection root, under `.vibecheck/`
  (§7 Storage). Track index and an append-only label log in one SQLite file,
  embeddings in a separate cache file, config in a text file. **decided**
- **Train**: fit a classifier on tracks that carry a label.
- **Predict**: for unlabelled/new tracks, output a label + confidence, or
  abstain below a threshold.
- **Write**: predicted labels go straight into the tag; review happens
  afterwards in the user's software. A dry-run mode writes nothing and only
  reports what would change.
- **Abstain**: a **configurable confidence threshold**, exposed to the user as a
  slider for how much wrongness they will tolerate. **decided** Below it a track
  is skipped rather than guessed at; it stays unlabelled and is retried later.
  Zero means label everything. Wrong labels are expected and fine — the point is
  that the user chooses the rate.
  For the slider to mean anything, the number behind it must be **calibrated**:
  logistic regression on high-dimensional embeddings is overconfident by
  default, happily reporting 0.97 on tracks it gets wrong, which would make the
  threshold inert. Fit a temperature scalar on the holdout, and document the
  slider in measured terms ("0.8 => ~85% of written labels correct on your
  holdout"), not in raw model self-report.
- **Playlists as work lists**: a run's working set can be restricted to the
  tracks in a `.m3u8`, and a run can report the tracks it touched as a `.m3u8`.
  Playlists never carry label information and are disposable. **decided**
- **Feedback**: detect labels that are new or changed since the last run by
  comparing each file's current tag to the last-seen value in the DB, and
  retrain on them.
- **Holdout, in three parts**: labelled tracks are bucketed by content hash
  into `hash % 10` — bucket 0 is **test**, bucket 1 is **validation**, the rest
  is training. **decided** Deterministic from content, so the split is stable as
  labels accumulate, survives renames, is reproducible after deleting the DB,
  and has no state to get out of sync.
  Three parts rather than two because picking the best of several backends
  against one holdout inflates the winner's score by selection alone. Backend
  choice and threshold tuning are decided on **validation**; **test** is looked
  at once, at the end. Roughly 860 tracks each at current label counts, which
  pins overall accuracy to about +/-1.5 points.
- **Evaluate**: report accuracy on the holdout — overall and per label — against
  the majority-class baseline. This is the only meaningful benchmark and drives
  every model choice.

### Non-functional
- Incremental and resumable: rescans touch only changed files; a killed run
  loses at most the current batch.
- Embeddings computed once per file and cached, keyed by **(content hash,
  backend, model version, preprocessing config hash)**. **decided** The content
  hash alone is not enough: switching backends, bumping a model version or
  changing a preprocessing parameter must invalidate the cache, or vectors from
  two different pipelines get silently mixed — the same class of invisible
  failure §4.2 exists to prevent. Content hashing means moves and renames never
  force a recompute.
- Parallel extraction across cores; must survive corrupt/unreadable mp3s.
- **Local-first**: runs entirely on a laptop-class machine, offline, no upload of
  audio. Cloud embedding stays a one-off benchmark, never a runtime dependency.
  **decided**
- **Portable**: must work on any user's mac and any user's collection.
  No hard-coded paths, no assumption about how much of a library is tagged, and
  no assumption about which label strings a user uses. Every collection bootstraps
  its own vocabulary from zero. **decided**
- Must degrade gracefully on a smaller machine: 8 GB RAM and no GPU should still
  work, just with a cheaper embedding backend.
- Never destroy tags: back up original tag values in the DB before any write.

### Scale estimate
Reference collection (measured 2026-09-09): **14,194 mp3, ~199 GB**, ~14 MB and
~6 min per track — DJ-length material at high bitrate. Other formats present but
out of scope: mp3 only, the user converts beforehand. **decided**

**Labels (measured 2026-09-09):** 8,619 tracks labelled (60.7%), 5,575 not.
Exactly **24 distinct strings, no typos**. Applied **by ear**, not derived from
metadata rules — so an audio-only model is being asked to predict something
audible, and the numbers will mean what they appear to mean.

- **Majority baseline 23.9%** (`Purple_C`, 2061 tracks). This is the number to
  beat; 1/24 = 4.2% is not the relevant floor.
- **Imbalance 412x**: `Purple_C` 2061 down to `Blue_A` 5, `Aqua_A` 8,
  `Green_A` 18, `Orange_A` 37. Seventeen labels have >= 100 tracks; four have
  under 30 and can be neither learned nor measured. Report per-label numbers
  only above ~30 examples and mark the rest as insufficient data.
- The reference vocabulary is `Colour_Level` over 8 colours and 3 levels, where
  **A is best** — hence the skew: **C 65%, B 30%, A 5%**. Few favourites, many
  merely-fine tracks.
- Consequence for reading results: "always guess C" already scores 65% on the
  level component while "always Purple" scores only ~27% on the colour, so
  nearly all the difficulty is in the colour. A single joint accuracy number
  hides this; the report decomposes both (diagnostic only — the app still
  treats labels as opaque, §5).

Reference machine: M1 Pro, 16 GB, collection on internal SSD. Sized for this,
but **must not assume it** — see portability below.

Decode is not a bottleneck: excerpt seeking reads ~1 MB per file, not 14 MB.

**Feasibility on the reference machine** — the 199 GB is a red herring; what
matters is 13.8k tracks x 90 s of sampled audio = ~350 h of audio to embed,
once. Estimated on M1 Pro: **under an hour** for a CNN backend, **5-10 h** (one
overnight) for a transformer one. After that, embeddings are cached and only new
files are processed — seconds each. Training and prediction are trivial at this
size, and 16 GB RAM is ample. The project is comfortably within the machine;
the binding constraints are user labelling effort and arm64 dependency friction,
not compute.

## 4. Pipeline

```
scan -> decode excerpts -> resample -> preprocess -> embed -> pool -> [cache]
                                                                        |
                             write tag <- categorise <- train <---------+
                                  |                       ^
                                  v                       |
                            batch.m3u8 -> user fixes -> tags
```

### 4.1 Stages

1. **Scan** — walk roots, stat files, partial hash (first + last N bytes + size).
2. **Decode** — mp3 -> PCM. Only the excerpt regions, not the whole file.
   mp3 seeking is frame-aligned and the bit reservoir makes the first frames
   after a seek inexact: decode slightly early and discard ~0.5 s.
3. **Resample** — models want a fixed rate (typically 16 kHz mono; MERT 24 kHz);
   mp3s are 44.1 kHz. The resampler is part of the model contract, not a detail:
   a different one shifts the embeddings.
4. **Preprocess** — log-mel spectrogram (or whatever the chosen model expects).
   **See 4.2 — this is where the project can silently lose accuracy.**
5. **Embed** — frozen model -> one vector per excerpt (512-1280 dim).
6. **Pool** — mean across the 3 excerpts, then L2-normalise. Store the
   per-excerpt vectors too: 3 x 1280 floats is 15 KB/track, ~200 MB for the
   library, which buys the freedom to re-pool later without re-decoding.
7. **Train** — logistic regression over pooled vectors, `source='user'` rows only.
8. **Categorise** — predict, apply the confidence threshold, write tags, report
   the batch as a playlist.

### 4.2 Where the DSP lives — the parity trap

The chain from file to embedding:

```
mp3 -> PCM 44.1k -> resample 16k -> STFT -> mel -> log -> neural net -> embedding
                    \_________________ DSP ____________/   \__ the model file __/
```

Normally the exported model file contains only the neural net; everything left
of it is done in python with librosa before feeding the model. Ship a native app
and someone has to rewrite that DSP — matching sample rate, window function,
window and hop length, centre padding, FFT size, magnitude vs power, mel band
count, mel scale formula (**htk** and **slaney** both exist and differ),
filterbank normalisation, log base, epsilon, and any final normalisation.

Get one wrong and the model receives inputs unlike anything it was trained on.
**Nothing errors.** The embeddings are just worse, accuracy drops a few points,
and the cause is invisible.

Three ways to place the DSP:

| option | what it means | cost |
|---|---|---|
| **A. inside the model file** | exported graph takes raw PCM, returns embedding; the app only decodes | export work per model; in-graph resampling is awkward |
| **B. reimplemented natively** | Swift computes mel via vDSP/Accelerate | must replicate librosa exactly; silent-failure risk; redo per model |
| **C. ship python in the app** | bundle python + librosa + onnxruntime | 200-400 MB, hardened-runtime friction — but zero parity risk |

**Decision: prototype in python (effectively C). Target A for the shipped app,
keep C as the fallback, never B.** **decided** A is the only option that is both
lean and parity-safe; B is the worst of both, hand-written DSP *and* the risk.

Bundle-size expectation for A: ONNX Runtime (~50 MB) + weights (30-100 MB) + a
few MB of app = a notarisable 100-150 MB `.app` with no python. C lands at
200-400 MB — acceptable if A fails, not the goal.

**Some models remove the problem entirely.** Raw-waveform models (MERT is
HuBERT-style: raw 24 kHz into a conv encoder) have no spectrogram to reproduce;
the only preprocessing is resampling. Mel-based models (effnet, CLAP) carry the
whole chain. So the model choice *is* the choice of how hard the port is —
prefer raw-waveform models when scores are close.

**Two things that cost nothing now and keep A reachable:** **decided**

- **Pin the preprocessing config as data in the repo** — sample rate, window,
  hop, n_fft, n_mels, mel scale, log base, epsilon, normalisation — never rely
  on library defaults. Librosa defaults have changed across versions, so an
  implicit default is a bug waiting for an upgrade. This config *is* the port
  spec later.
- **Keep decode behind a narrow interface** — one function, `(path, offset,
  duration) -> float array`. Then swapping ffmpeg for AVFoundation is a one-file
  change, and the brew prototype never forecloses the notarised `.app`.

**The parity test**: embed a fixed set of ~50 tracks through both paths and
compare cosine similarity, expecting > 0.999. Written once, it catches this
entire bug class permanently.

### 4.3 Two runtimes, one artifact

Research and shipping have opposite needs: research wants every model available
and fast iteration; shipping wants a small signed binary with no toolchain.
Resolve it by making the **exported model file the contract between them**.
**decided**

- **Research (Phase 0)**: python. torch/transformers/librosa, whatever it takes
  to try candidates. Ends by exporting the winner to ONNX (with preprocessing
  baked in) and recording its accuracy.
- **Shipping**: a native binary that loads that ONNX file. No python, no torch.
- Export cleanliness is a **selection criterion**, not an afterthought. A model
  that scores well but will not export with its preprocessing is not a
  candidate. No ready-made ONNX exports of the leading music embedding models
  were found, so budget export work per candidate and verify numerically
  (cosine similarity vs the python reference on a fixed set of tracks) before
  trusting any of it.

### 4.4 Training must ship, not just inference

Most ML apps ship **inference only**: the developer trains, freezes and ships a
model file. This one cannot. The classifier is trained on the user's machine
from their own labels, repeatedly — everyone has different taste — so the
**training code must live inside the shipped binary**, not just the prediction
code.

That is normally what forces an app to bundle python and sklearn. Here it does
not, provided the classifier stays small: multinomial logistic regression over
~14k x 1280 floats is one matmul plus a softmax to predict (~10 lines) and a few
dozen lines of gradient descent to fit, running in seconds.

So logistic regression is the **default, not a ban**. Keep the classifier behind
a narrow boundary so a heavier one is a contained change, and require evidence
before paying for it: measure whether anything actually beats LR on real labels.
Lean and fast where possible — but a big app beats no app, so if a heavier
classifier is what makes the thing work, ship it.

### 4.5 Tech per stage, under the packaging constraint

Packaging an installable, notarised mac app rules some things out.

Target platform is **any desktop the user runs**, with macOS on Apple Silicon
as the development machine. *(revised 2026-09-13.)*

Keeping this open rules out the native per-platform app: three codebases for a
shared core of a few hundred lines is the wrong ratio. It makes the ONNX plan
below *more* valuable rather than less -- ONNX Runtime exposes CUDA, DirectML,
CoreML and CPU providers behind one API, so a single exported model file is
accelerated everywhere with no platform-specific code.

Expected shape: Python host + ONNX Runtime + a local web UI. One codebase, one
model file, one interface, ~500 MB packaged instead of ~2 GB with torch.

| stage | shipped-app option | notes |
|---|---|---|
| decode | `minimp3` (public domain, single header) | tiny, embeddable, no license issue |
| | AVFoundation / ExtAudioFile | native macOS, zero dependency, mac-only |
| | ~~ffmpeg~~ | **avoid in the shipped app** — see below |
| resample | baked into the model graph (4.2) | preferred |
| | libsamplerate (BSD) / Apple AudioConverter | fallback |
| preprocess | baked into the model graph (4.2) | preferred |
| inference | ONNX Runtime (+ CoreML EP) | portable, one artifact everywhere |
| | CoreML | ANE, smallest bundle, mac-only |
| classifier | hand-written LR | ~50 lines, trains and predicts |
| storage | SQLite | in every runtime already |

**ffmpeg: depend on it, do not bundle it.** **decided** The distinction matters
and only one side of it is a problem:

- *Depending* on it — a brew formula with `depends_on "ffmpeg"`, called as a
  subprocess — is clean. Nothing is redistributed, calling a separate program at
  arm's length creates no derivative work, and the MIT license is unaffected.
- *Bundling* it inside a distributed `.app`/`.dmg` means redistributing
  GPL/LGPL binaries, and the obligations attach to the distribution.

So: **prototype ships via brew with ffmpeg as a dependency.** The concern only
returns for a double-clickable notarised `.app`, and on mac that is solved for
free by AVFoundation, which decodes mp3 natively with no dependency at all —
a one-file change behind the decode interface (§4.2).

Shipping stack, *revised 2026-09-13*: **Python + ONNX Runtime + a local web
UI**, packaged per platform. Swift with AVFoundation and CoreML would give the
smallest mac bundle and Neural Engine access, but only on mac; with
cross-platform kept open it is no longer the right trade.

**Parked until the app is actually built** *(2026-09-13)*: **CLAP has never
been exported to ONNX.** MERT was, and matched the python reference exactly
(cosine 1.000000), but CLAP is mel-based and it is what ships, so its
preprocessing has to survive the export intact.

Deliberately not resolved now. It is half a day of work whenever it is needed,
nothing depends on it until packaging starts, and the answer could be made
irrelevant by any of the things still in flux -- a different backend winning on
fresh labels, a cloud encoder, or a change of interface. Resolving it early
would be optimising a decision we might not have to make.

**It must be settled before any packaging work begins**, because it decides
what is being packaged: ONNX Runtime plus a model file (~500 MB) if the export
is clean, or a bundled Python and PyTorch (~2 GB) if it is not. Designing a
distribution pipeline around the smaller number and then discovering the larger
one is the specific mistake to avoid.

### 4.6 macOS distribution requirements

Wanting other people to install this on their macs implies, concretely:

- **Prototype distribution is brew** — no signing, no notarisation, no Apple
  account needed. **decided** Everything below applies to the later `.app`, and
  the point of §4.2 and the decode interface is that nothing in the prototype
  forecloses it.
- **Apple Developer Program membership** (~$99/yr) for a Developer ID
  certificate. There is no notarisation without it.
- **Codesign + hardened runtime + notarise + staple.** Unnotarised downloads get
  progressively more hostile Gatekeeper treatment on recent macOS.
- **arm64-only is acceptable** (M1 or newer, per the constraint) — no universal
  binary needed.
- **Ship the model weights inside the bundle** (30-100 MB) rather than
  downloading on first run; no hosting, no integrity checks, works offline.
- **File-access permission**: a `.app` must obtain its own consent to read the
  user's music folder, unlike a CLI run from Terminal which inherits the
  terminal's. Verify what macOS currently requires for `~/Music` before
  assuming it is unrestricted, and avoid the Mac App Store sandbox unless
  there is a reason to accept it.

### 4.7 Near-duplicate grouping — considered, dropped

Originally the holdout was to be decided per group of near-identical tracks, so
a track and its own copy could not sit on opposite sides of the split and
inflate the score. **Dropped. decided**

Two reasons, both from the actual collection:

- True duplicates are rare here, so the leak it prevents is small.
- **Remixes and variations are labelled differently on purpose** — the user
  hears them as different, which is the whole premise of the project. Grouping
  by audio similarity would have pulled deliberately-distinct labels into one
  group and done active harm.

The holdout is therefore a plain per-track split, keyed on the content hash.
Simpler, and it respects what the labels actually mean.

## 5. Labels

**One flat set of label strings. One label per track. That is the entire
model.** **decided**

**Prediction is hierarchical even though labelling is not.** **decided** The
user only ever applies the flat labels. The app derives coarser groupings from
a declared hierarchy and predicts the finest level it is confident about, which
is what makes it useful at all: 8-way colour is only ~56% accurate, but the
2-way tone derived from it is ~80%. Writing "Dark" beats writing a wrong colour
or writing nothing. See §5a.

- The vocabulary is whatever strings the user provides — e.g. `Red_High`,
  `Red_Mid`, `Red_Low`, `Green_High`, ...
- The app assigns **no meaning** to them: no axes, no ordering, no hue, no
  rating, no adjacency, no parsing of the string. They are opaque symbols.
- Any structure lives in the user's naming convention and their head only.
- The label is written to the track metadata as-is; no composition, no template.

So: **a single N-class classifier over the user's label set.** Nothing else.

Cost of this, stated once for the record: a flat 24-value vocabulary needs
examples for all 24 (~20 each at the few-shot knee, so ~500 labels) where a
structured scheme could have shared data across values and needed roughly half
that. Accepted deliberately — the app not knowing anything about label semantics
is worth more than the labels saved, and it is what makes the tool work
unchanged for anyone else's scheme.

### 5a. Cascading prediction

Measured on held-out data, predicting one label per track caps out around 56%
for eight colours. The same model reaches ~66% at four hue families and ~80% at
two tones, because those distinctions are carried more strongly by the audio.

So the app predicts all three from the same user labels, and emits the finest
one that clears a confidence threshold:

```
confident about the colour  -> write "Purple"
only about the hue family   -> write "Vibrant"
only about the tone         -> write "Dark"
confident about none        -> write nothing
```

Thresholds are not set by hand, and in fact there are none. The app scores each
option by the work it leaves the user -- how many binary choices remain -- and
picks the cheapest. Near-misses get partial credit: a wrong colour with the
right hue costs one choice, not a restart. The cascade falls out of that
arithmetic rather than being imposed.

One dial: `misleading_cost`, how bad it is to be misled by a wrong label.
Measured per 100 new tracks, against 3.00 for labelling by hand:

```
misleading_cost = 1   55 exact, 32 near, 9 wrong,  0 silent   1.31   56% less work
misleading_cost = 2   46 exact, 21 near, 5 wrong,  2 silent   1.73   42% less work
misleading_cost = 3   33 exact, 10 near, 2 wrong, 16 silent   2.01   33% less work
```

The honest caveat, recorded so it is not forgotten: most of the coverage is
tone. "Dark", correct 88% of the time, is a much weaker statement than "Purple"
correct 88% of the time. This is a labelling accelerator, not an auto-labeller.

### What to expect from a taste-based vocabulary

Not app behaviour — realistic expectation-setting for the reference vocabulary,
whose labels mix a "sound" component with a "how much do I like this" component.
The second is the risky part:

- Preference is weakly predicted by audio in general; that is why recommenders
  lean on collaborative filtering rather than the signal itself.
- **Range restriction** makes it harder here: the library is already curated,
  every track passed a bar to be kept, so the easy variance is gone and what
  remains is fine discrimination inside a selected pool. That is exactly the
  point of the app, and also the reason it is hard.
- Part of preference is not in the audio at all: novelty, recency, whether a
  track has been played out, whether it fits a current set.
- Self-consistency on that component will be lower than on the sound component,
  and the ceiling binds there first.

Consequences for evaluation, which *are* app behaviour:

- **The baseline to beat is always-predict-majority, not 1/N.** A 24-class
  problem where one label covers 30% of tracks means 30% is the floor, not 4%.
- **Report per-label accuracy, not just overall.** If the sound component is
  learnable and the preference component is not, that shows up as labels
  sharing a prefix being confused with each other — visible per-label, invisible
  in the aggregate number.
- **Abstain is per-label-confidence**, and a wrong suggestion costs more than no
  suggestion.
- If Phase 0 shows the model can only reach the majority baseline, the honest
  outcome is to say so rather than ship a coin flip.

## 6. Interface and workflow

**The label lives in the mp3 tag. Nowhere else.** Playlists carry no label
information whatsoever — they are temporary work lists: which tracks a run
should operate on, and which tracks a run touched. They are disposable and get
deleted often. **decided**

The app never plays audio. Judging a track means listening to it, and the user's
own music software is already the best place for that.

### Core vs interface

The architecture is a **core engine** plus thin front ends. The core owns
everything real: index, embed, train, predict, select a batch, read/write tags,
read/write playlists. A front end only maps user intent onto those operations
and prints results. **decided**

The CLI sketch below is illustrative — a rough shape to reason about, **not a
settled interface**. Flag names, subcommand split and defaults are deliberately
unresolved until the architecture is proven; getting the core right comes first,
and a wrong interface is cheap to change while a wrong core is not.

As built, the loop is one command:

```sh
vibecheck label 100     # read corrections, refit, predict 100, write the xml
```

`sync` remains for reading corrections without generating a batch -- relabelling
old tracks, say. It is rarely typed.

**Why `label` syncs first.** **decided 2026-09-19** The model is fitted from
whatever is in the database at that moment, so labelling before syncing trains
on stale data and wastes the round -- silently, since nothing about the output
says which labels it used. Ordering the two commands correctly was the user's
job and had no upside; now it is not. `--no-sync` opts out.

Corrections are read back through the same channel the predictions were written
to: the rekordbox export, or genre tags when rekordbox is not in use. With
neither there is no channel, and the step is skipped rather than failing.

An export older than the open batch is a warning, not an error: generating a
new batch while an earlier one is still being corrected is legitimate. It says
so loudly, because the alternative reading -- that the corrections were taken
when they were not -- is the expensive mistake.

There is no separate "train" step: the model is refitted at the start of the
next `label`, from whatever labels exist then. `sync` only records.

**What `sync` reads, as built.** Two kinds of evidence, treated differently:

- A value that **differs** from what the database holds is unambiguous -- only
  the user could have changed it -- so it is taken whatever the scope. Scoping
  the read is how corrections to tracks outside the current batch got missed.
- A value that **matches** a prediction is ambiguous: reviewed and agreed, or
  not yet looked at. Adopting those without evidence of review is what once
  imported 8,595 retired labels. The evidence is the open round -- the database
  knows which tracks are out in a batch that has not been synced -- so the
  common case needs no playlist argument.
- A colour on a track the database has no record of is a third case: another
  tool's work, or an older scheme. Ignored unless it is in the reviewed scope
  or `--all` is given, and reported rather than silently skipped.

What matters at this stage is only the shape:

- a run's **working set** is either the whole collection or the tracks in a
  playlist;
- a run can **bound how much work it does**;
- a run can **report which tracks it touched** as a playlist, so they can be
  reviewed in the user's software.

### The round trip

```
categorise a batch, report it as batch.m3u8  ->  labels written into tags
open batch.m3u8 in music software            ->  user listens, fixes wrong tags
train over batch.m3u8                        ->  corrections picked up, retrain
```

Corrections are just tag edits. They are detected by comparing each file's
current tag against the value last recorded in the DB, which is why the index
keeps the last-seen label and a label history (§3).

Nothing about a playlist is authoritative and nothing is inferred from absence:
a track missing from a playlist simply is not part of that batch.

### The normal workflow

Simplicity is the priority. The expected use is not "sit down and train a
model", it is: **new music arrives, the app labels it, the user corrects what is
wrong while DJing, and the app picks that up by itself.** **decided**

- **Corrections are detected, not declared.** The app compares each file's
  current tag against the value last recorded in the DB. A changed tag is a
  correction and becomes a `source='user'` row. The user never has to say "I
  reviewed these".
- **This needs no daemon.** An incremental scan is cheap — stat 14k files, then
  read tags only for files whose mtime or size moved — so every run starts with
  one. A scheduled background run is an option, not a requirement.
- **The app must not learn from itself.** A label the app wrote is logged as
  `source='model'`. If the tag still matches what the app wrote, nothing
  happened and no user row is created. Only genuine differences count. Without
  this the model retrains on its own guesses and amplifies its own errors.
- **Explicit confirmation stays available** for the case where the user *has*
  deliberately reviewed a batch: training over a playlist means "these labels
  are mine now", changed or not. Over the whole collection it means only
  "pick up what changed" — it must never promote unreviewed model labels.
- **Taste drifts, and that is normal.** The log is append-only and the newest
  row for a track wins, so relabelling a track years later simply supersedes.
  Timestamps make recency-weighted training possible later; not needed now.

### Which tracks to work on

Two different jobs, with opposite selection criteria — conflating them produces
an empty batch, because one asks for the tracks the other refuses to touch:

**Bulk labelling (the user-facing job).** Label as much new music as possible.
Take the tracks the model is **most** confident about; the confidence threshold
skips the rest for a later run. Unattended, writes tags, `--limit` is throughput.

**Uncertainty review (a development tool, not a user feature).** **decided**
Take the tracks the model is **least** sure about — they teach the most per
listen. Nobody wants to be handed a random pile of music to educate a
classifier, so this stays a diagnostic for tuning and evaluating the model
during the prototype, and is not part of the normal workflow.

For the record, if it is ever wanted as a user feature, the selection method is
active learning: cold start by farthest-first traversal (k-center greedy) over
embeddings; once trained, margin sampling (`p(top1) - p(top2)`, smallest first)
over a candidate pool, greedily diversified so the batch is not 20 copies of the
same confusion; with a slice of pure random picks, since actively-selected
tracks are a biased sample and accuracy measured on them means nothing.

Retraining takes seconds at this size, so it happens whenever labels change; no
incremental algorithm is needed.

**Prerequisite**: tracks must be embedded before they can be labelled or
selected. That batch cost is unavoidable, which is why Phase 0 measures
extraction wall-clock per backend, not only accuracy.

Runs report progress: labels so far, holdout accuracy against the majority
baseline, and which labels are still weak.

### Playlist I/O robustness

Playlists come back from software the app does not control, so import must be
forgiving: **decided**

- `.m3u8` is UTF-8 by definition; write it as such, read it as such.
- Match entries to indexed tracks by, in order: exact path, normalised path
  (percent-decoding, `file://` prefixes, separator differences, resolved
  relative paths, case-insensitive on macOS), then content hash, then basename.
  Report anything still unmatched rather than silently dropping it — a silent
  drop looks like the user removing tracks from a batch.
- Write absolute paths on export; assume nothing about what comes back.

## 7. Tech candidates

Backends are not chosen; the surrounding decisions below are.

**Audio decode**: `ffmpeg` subprocess (robust, handles anything, easy seeking to
excerpts) vs a library binding. ffmpeg is the safe default.

**Tag read/write**: `mutagen` (python, ID3 native) or TagLib. mutagen if the
prototype is python.

**Embeddings** (feature extractors only):
| candidate | notes |
|---|---|
| Essentia discogs-effnet | music-specific, CPU-cheap, embedding layer exposed |
| MERT-v1-95M | self-supervised music transformer, strong on music tasks |
| CLAP (LAION) | audio-text contrastive; strong general audio, music decent |
| OpenL3 / VGGish | older, cheap, weaker |
| MFCC/chroma/tempo baseline | trivial, no deps — the floor to beat |

Recent benchmarks show no universal winner; ranking is task-dependent. So:
implement 2-3 behind one interface, measure on the user's own library, keep
the winner.
The MFCC baseline is mandatory — if a 200 MB neural model doesn't clearly beat
it on real labels, it isn't worth carrying.

**Local vs cloud**: **local. decided.** Measured scale (13.8k tracks) puts a
full-library embed at well under an hour for a CNN backend and one overnight run
for a transformer one, on the reference M1 Pro. Cloud is kept only as a one-off
Phase 0 comparison (~$7 on a 500-track subset) to know what is being given up —
never a runtime dependency.

**Hardware**: reference is M1 Pro / 16 GB, but **no design may assume a GPU**
(portability, §3). Cheap CPU backends (effnet, MFCC) must stay viable; anything
heavier is an optional accelerated path. Install-cleanliness on arm64 macOS is a
first-class selection criterion — prefer **ONNX Runtime** (clean arm64 wheels,
CoreML EP) over TensorFlow / `essentia-tensorflow`, whose Apple-silicon story is
the most likely place to lose a weekend. A backend scoring 3 points higher but
needing a bespoke toolchain is the wrong choice for a solo-maintained tool.

**Storage**: in the collection root, under a `.vibecheck/` directory:
**decided**

```
~/Music/Collection/.vibecheck/
  config.toml     # handful of options, human-edited
  labels.db       # track index + label log — precious, tiny (~5 MB)
  cache.db        # embeddings — large, regenerable, deletable
```

**Why in the collection root** — consequences that fall out for free:

- **The index travels with the collection.** Move, rename or copy the folder and
  the labels, embeddings and history come along. Nothing to re-derive.
- **Store paths relative to the root**, which the directory defines. The
  collection can then be mounted anywhere — different user, machine, external
  drive — without invalidating every row.
- **The collection root is the only configuration.** No `~/.config` state, no
  registry of known libraries, no ambiguity about which collection a run means.
  Several collections are simply several folders, each self-describing.
- Multi-user portability (§3) comes free: hand someone the folder, they have a
  working index.

**Why three files and not one:**

- **The label log is the only irreplaceable thing in the project.** It is hours
  of listening. Embeddings cost 5-10 h of CPU but are re-derivable from the
  audio at any time; the log is re-derivable from nothing. Separate files mean
  the log can be backed up, synced, even kept in git, while a 100 MB+ cache is
  ignored — and the cache can be deleted to switch embedding backends without
  ever putting the log at risk.
- **Config a human edits belongs in a text file, not rows in a binary DB.** A
  handful of options in `config.toml` is editable, greppable and diffable, and
  needs no subcommand to change a threshold. The DB holds only data the program
  owns.

**Journal mode: default rollback journal, not WAL.** **decided** WAL only pays
off for concurrent readers alongside a writer, which never happens here — one
process doing batch work. Default mode keeps each DB a single file at rest, with
no `-wal`/`-shm` sidecars in the collection. `synchronous=FULL`; the write volume
is far too low for the difference to matter.

**The palette is fixed.** **decided, reversing §2** Rekordbox exposes exactly
eight colour tags and six star ratings. That is the target software's UI, not a
matter of taste, and modelling it as opaque strings was generality about the
wrong thing: it bought vocabulary-independence nothing will use, and paid for
it by making hue, tone and rating unqueryable -- every statistic had to re-parse
a string against a config file to find out what it was looking at.

The structure now lives in `palette.py`, typed, and in a seeded `colours`
table: id, name, hue, tone, and the hex rekordbox writes. Hue and tone are a
property of the eight, not an opinion. What stays personal -- and it is the
whole product -- is *which track gets which colour*, which is learned rather
than declared. A label is a colour and a rating, each nullable, each meaning
"nothing was said" when absent.

**A record of what happened, not a snapshot of where things stand.**
**decided** Everything derivable is derived: the current label is the newest row
in `labels`, the collection's size on any past date comes from `first_seen` and
`missing_at`, and how well a round did comes from joining what the model said to
what the user said afterwards. A number overwritten today is a chart that cannot
be drawn next month.

```sql
colours     id, name, hue, tone, rgb                 -- seeded, eight rows
tracks      id, path, hash, size, mtime, first_seen, last_seen, missing_at
rounds      id, name, started, closed, size, backend, encoder, n_labels
labels      id, track_id, colour_id, stars, source, round_id, ts  -- append-only
predictions (round_id, track_id), hue, hue_p, hue_said,
                                  tone, tone_p, tone_said,
                                  stars, stars_p, stars_said, colour_id
fits        id, round_id, ts, backend, encoder, slice,
            n_train, n_holdout, n_labels
fit_axes    (fit_id, axis), n_values, cost, misleading,
            n, spoke, correct, cost_left
current     view: newest label per track, with hue and tone spelled out
```

**Files are identified by audio hash, referred to by `id`.** **decided** A
rename is then a rename: scan matches the new path to the existing row and
updates it in place, keeping the track's labels and its listening history. Only
unambiguous moves count -- with two copies of the same audio there is no way to
say which one moved, and guessing would attach one track's history to another.

**`first_seen` is written once; files that vanish are marked, never deleted.**
**decided** The previous schema had a single `seen_at` that every scan
overwrote, which made the library's growth -- one of the things the user asked
to see -- unrecoverable. `first_seen` plus `missing_at` gives the collection's
size at any date, for the price of one integer.

**One row is one complete statement about a track.** **decided** That is how
the data arrives: rekordbox hands over a colour and a rating together. NULL
means the statement said nothing on that axis -- a round sure of the colour and
not the rating. `stars = 0` is different, being rekordbox's "unrated", which is
an answer. Having no row at all is different again: never asked, or never
answered, so the `current` view exposes `label_id` to tell those apart.

That distinction has teeth. Reading an export back, a round that asserted a
colour and stayed silent on the rating returns as `(colour, 0 stars)` and looks
changed although the user touched nothing -- so `sync` compares only the axes
the earlier statement actually made.

**`source` is not bookkeeping, it is a correctness requirement.** **decided**
Without it: a round writes a tag, a later training run reads that tag back, and
the model trains on its own output -- a feedback loop that quietly amplifies its
own errors until the labels are the model's opinion rather than the user's.
Training consumes `source='user'` rows only. For the same reason, reading labels
out of genre tags at scan time is opt-in (`--adopt-tags`): the app writes genre
tags itself, and writes the colour without the rating, so a differing tag is as
likely to be its own output as a correction. Corrections come through `sync`,
which knows which round they answer.

**`round_id` joins the two halves of a round.** **decided** A round is a
prediction followed, days later, by a correction. Without a shared key the two
can only be reassociated by clustering timestamps, which is guesswork that
breaks the first time two batches are in flight at once. `label` opens the round
and names it after its playlist; `sync` carries that id onto the user's row and
closes it.

**Predictions are recorded per axis, including the silent ones.** **decided**
One wide row per track per round, so it joins 1:1 against the label row that
followed. The colour alone cannot say *why* it was that coarse -- whether an axis
was silent, or wrong, or never trained. Keeping `value` and `conf` for axes that
stayed silent also makes the threshold reviewable: "what would
`misleading_cost = 2` have done to that round?" becomes a query, rather than a
re-run of a model that has since learned from the answers.

**`fits` is separate from `rounds`.** **decided** Coverage, accuracy and
decisions-left per axis were being computed every round, printed, and discarded.
They are measured on the hash-derived holdout by a second fit that never sees it
-- the deployed model is fitted on everything, which is right for predicting and
useless for measuring. Separate, because a fit can also be a plain measurement:
the once-only test-slice reading at the end, or a later re-measurement of
history. `encoder` (backend/version/preproc digest) is stored with both, so a
jump in a curve can be attributed to the model improving rather than the inputs
changing underneath it.

A consequence worth stating: the holdout only exists if labelled tracks fall in
it. The first 300 labels came from a blind relabel drawn entirely from the
training split, so they measure nothing; batches are drawn at random, so ~20% of
each one lands in val or test and measurement becomes possible from the first
round onward. That 20% is the price of being able to tell whether any of this is
working.

**Migrations: plain SQL keyed on `PRAGMA user_version`.** **decided** No
framework. Alembic is the standard and is alive, but it needs SQLAlchemy and
its value -- autogenerate, a branching revision graph, team workflows -- has no
purchase on one developer and six tables. yoyo, refinery and Alembic all keep
their own bookkeeping table, and *that* is the part that would commit us:
`user_version` is a SQLite built-in every language reads in one line, so the
runner can become rusqlite, Dart or Node later without two disagreeing records
of what version a database is. No frontend is chosen (docs/frontend-options.md),
and this is the option that does not presuppose one.

Steps live in `src/vibecheck/migrations/NNNN_name.sql`, read through
`importlib.resources` so an installed app finds them with no source tree beside
it, and the number is the version a database is *at* once the step has run.
Each step is one transaction; SQLite rolls back DDL, so a failure leaves the
database exactly where it was. Anything but a fresh database is copied to
`labels.db.pre-v<n>` first -- `rounds`, `predictions` and `fits` exist nowhere
else, and rekordbox can restore what a track is labelled but not what the model
predicted or what a round cost.

Two rules, both learned the hard way in one afternoon: a migration never uses
`IF NOT EXISTS` -- one that silently does nothing is worse than one that fails
-- and a database older than the baseline is refused, never run through it. The
baseline builds the schema from nothing, so over an older database it would
find every table present, do nothing, and stamp the new version anyway, leaving
a database that claims v3 while holding v2's columns. `tests/test_migrations.py`
covers both, and adding a migration means adding a fixture database built by the
previous build.

**The genre tag is off by default.** **decided 2026-09-16** It was written to
make partial predictions visible -- rekordbox's colour swatch can only show a
colour, so there was no way to see that a track had been narrowed to a hue
rather than named. Once the model names a colour on ~99 tracks in 100 there is
nothing left for it to reveal, and it was writing to every file for nothing.
The capability stays for anyone not using rekordbox: with
`debug.write_genre_tags` on, the genre field is the whole channel and
`sync --tags` reads corrections back out of it.

**Model loading is cache-first, and offline once cached.** **decided
2026-09-16** `from_pretrained` contacts the Hub on every call to check the
revision even when the weights are local, so a tool that is otherwise entirely
local needed an internet connection to start -- and printed a rate-limit
warning each run. `local_files_only=True` stops the fetch but not a deferred
check that follows it, so `HF_HUB_OFFLINE` is set too, and only when the model
is genuinely cached, which leaves the first-run download working. Every load
failure is now reported with its reason: "could not load CLAP" with no cause
was not something anyone could debug.

**Caution for other setups**: SQLite on cloud-synced storage (Dropbox, iCloud)
can corrupt. Irrelevant on the reference internal SSD, but worth a warning for
anyone whose collection lives on synced storage.

**Prototype runtime**: python — all the model tooling lives there.

**Playlist I/O**: `.m3u8` read/write is a few dozen lines; no library needed.
The work is path normalisation on import, not parsing.

**Config format**: TOML — stdlib `tomllib` in python 3.11+, no dependency.

**App shell**: deferred, and possibly never — see Phase 2. If it happens:
Godot UI + local sidecar over stdio, a python GUI, or Tauri.

## 8. Roadmap

**Phase 0 — feasibility. Deliverable: numbers, not software.** *(in progress)*
Python. In practice the scanning, storage and embedding-cache parts follow the
schema in §7 and are worth keeping into Phase 1; only the reporting is
throwaway. Take the tracks already labelled by hand, embed them with 2-3
backends plus the MFCC baseline, and measure. In this order — the order matters:
**decided**

1. implement the backends behind one interface;
2. **export spike per candidate**: export to ONNX with preprocessing included,
   one track, check cosine against the python reference. Half a day each, and it
   can veto a model *before* any bulk work;
3. embed the labelled subset; measure accuracy and wall-clock;
4. pick the winner on accuracy + wall-clock + export feasibility together;
5. only then embed the full library.

Measuring accuracy first, picking a winner, then discovering it will not port is
how a project ends up hand-writing DSP with the labelling effort already spent.

Reporting: holdout accuracy overall and per label against the majority baseline,
a learning curve (accuracy vs labels per label-value), and wall-clock plus
install friction per backend. The learning curve answers "how many labels does
this actually need" empirically, instead of guessing a number in advance.

*Go/no-go*: does any backend beat always-guessing-the-commonest-label by a
margin worth building on? If not, stop here — a valid outcome, cheaply reached.

**Phase 1 — usable CLI. Deliverable: a tool in daily use.**
Scan and index the full library, embed everything (the overnight job), train,
bulk-label with the confidence threshold, write tags, incremental rescan that
picks up corrections automatically, playlists as work lists. This is where it
starts saving work.

**Phase 2 — refinement. Deliverable: it improves efficiently.**
Calibration, progress reporting, near-duplicate grouping, and the uncertainty
review tool (§6 — a development aid, not a user feature). Deliberately later:
with thousands of labels available up front, none of this is load-bearing for
the thing working.

**Phase 3 — the app. Deliverable: something other people can install.**
Swift, ONNX export with preprocessing baked in, AVFoundation decode, codesign,
notarise, `.dmg`. Only worth doing once Phases 0-1 prove the idea and the CLI
has been lived with.

## 9. Open questions

Deferred until Phase 0 produces numbers (cannot be answered by opinion):
- Which embedding backend wins on real labels, at what wall-clock and install
  cost.
- Whether any cloud backend is worth a one-off comparison run.
- Where the learning curve flattens — how many labels this problem needs.
- Whether anything beats plain logistic regression enough to justify shipping a
  heavier classifier (§4.4).

Known, accepted, not problems to solve:
- **Anchoring**: reviewing a suggested label is not the same as labelling blind,
  so acceptance rate is not evidence of accuracy. Nothing to fix — just never
  report acceptance rate as accuracy; the holdout (§3) is the honest number.
- **Taste drift**: labels legitimately change over time. Newest row wins.

Open for the maintainer, but not blocking:
- Ceiling check: relabel ~100 tracks blind and compare against the earlier
  labels. That self-agreement rate is the real accuracy target; chasing above
  it is chasing noise.

## References

- [Essentia models](https://essentia.upf.edu/models.html)
- [MAEB: Massive Audio Embedding Benchmark](https://arxiv.org/pdf/2602.16008)
- [CLAP vs MERT fine-grained comparison](https://www.mdpi.com/2079-9292/15/8/1723)

## License

MIT — see [LICENSE](LICENSE).
